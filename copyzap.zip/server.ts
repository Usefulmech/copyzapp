import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import multer from "multer";
import { createServer as createViteServer } from "vite";

interface StoredMemory {
  id: string;
  userId: string;
  title: string;
  body: string | null;
  link: string | null;
  imageUrl: string | null;
  imageType: string | null;
  createdAt: string; // ISO string
  isPinned: boolean;
  archivedAt: string | null;
}

interface StoredToken {
  userId: string;
  shareToken: string;
  createdAt: string;
}

const PORT = 3000;
const DATA_DIR = path.join(process.cwd(), "data");
const UPLOADS_DIR = path.join(process.cwd(), "data", "uploads");

// Ensure data and upload directories exist
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const MEMORIES_FILE = path.join(DATA_DIR, "memories.json");
const TOKENS_FILE = path.join(DATA_DIR, "tokens.json");

// Helper to load and save data
function loadMemories(): StoredMemory[] {
  try {
    if (fs.existsSync(MEMORIES_FILE)) {
      const content = fs.readFileSync(MEMORIES_FILE, "utf-8");
      return JSON.parse(content);
    }
  } catch (err) {
    console.error("Failed to load memories:", err);
  }
  return [];
}

function saveMemories(memories: StoredMemory[]) {
  try {
    fs.writeFileSync(MEMORIES_FILE, JSON.stringify(memories, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save memories:", err);
  }
}

function loadTokens(): StoredToken[] {
  try {
    if (fs.existsSync(TOKENS_FILE)) {
      const content = fs.readFileSync(TOKENS_FILE, "utf-8");
      return JSON.parse(content);
    }
  } catch (err) {
    console.error("Failed to load tokens:", err);
  }
  // Default demo token if none exists
  const defaultToken: StoredToken = {
    userId: "user_demo_default",
    shareToken: "cz-demo-7f8e9a2b1c3d4e5f6a7b8c9d0e1f2a3b",
    createdAt: new Date().toISOString(),
  };
  saveTokens([defaultToken]);
  return [defaultToken];
}

function saveTokens(tokens: StoredToken[]) {
  try {
    fs.writeFileSync(TOKENS_FILE, JSON.stringify(tokens, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save tokens:", err);
  }
}

// In-memory cache loaded from disk
let memoriesStore: StoredMemory[] = loadMemories();
let tokensStore: StoredToken[] = loadTokens();

// Multer storage setup for handling file uploads in share target
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || getExtensionFromMime(file.mimetype);
    const uniqueName = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}${ext}`;
    cb(null, uniqueName);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit per share spec
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

function getExtensionFromMime(mime: string): string {
  switch (mime) {
    case "image/png": return ".png";
    case "image/jpeg": return ".jpg";
    case "image/gif": return ".gif";
    case "image/webp": return ".webp";
    default: return ".jpg";
  }
}

// Timing-safe token comparison helper
function validateShareToken(providedToken: string): StoredToken | null {
  if (!providedToken) return null;
  for (const t of tokensStore) {
    try {
      if (crypto.timingSafeEqual(Buffer.from(t.shareToken), Buffer.from(providedToken))) {
        return t;
      }
    } catch {
      // In case lengths differ
      if (t.shareToken === providedToken) return t;
    }
  }
  return null;
}

// Helper to extract URL from text if present
function extractUrl(text?: string | null): string | null {
  if (!text) return null;
  const urlRegex = /(https?:\/\/[^\s]+)/gi;
  const matches = text.match(urlRegex);
  return matches && matches.length > 0 ? matches[0] : null;
}

// Cleanup function to purge items older than 24h (unless pinned)
function performCleanup(): number {
  const now = Date.now();
  const TWENTY_FOUR_HOURS_MS = 24 * 60 * 60 * 1000;
  const initialLength = memoriesStore.length;

  const validMemories: StoredMemory[] = [];
  const deletedImages: string[] = [];

  for (const memory of memoriesStore) {
    const age = now - new Date(memory.createdAt).getTime();
    if (age > TWENTY_FOUR_HOURS_MS && !memory.isPinned) {
      if (memory.imageUrl) {
        const filename = path.basename(memory.imageUrl);
        deletedImages.push(filename);
      }
    } else {
      validMemories.push(memory);
    }
  }

  // Delete associated image files
  for (const filename of deletedImages) {
    const filePath = path.join(UPLOADS_DIR, filename);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (e) {
        console.error("Error removing image file during cleanup:", e);
      }
    }
  }

  memoriesStore = validMemories;
  saveMemories(memoriesStore);
  return initialLength - validMemories.length;
}

// Run cleanup every 15 minutes
setInterval(performCleanup, 15 * 60 * 1000);

async function startServer() {
  const app = express();

  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ extended: true, limit: "10mb" }));

  // CORS headers
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // Serve uploaded images statically
  app.use("/uploads", express.static(UPLOADS_DIR));

  // Rate limiting map for share-receiver (30 requests/minute per IP)
  const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
  const rateLimiter = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();
    const record = rateLimitMap.get(ip);

    if (!record || now > record.resetTime) {
      rateLimitMap.set(ip, { count: 1, resetTime: now + 60000 });
      return next();
    }

    if (record.count >= 30) {
      return res.status(429).json({ error: "Too Many Requests (Rate limit: 30 shares/min)" });
    }

    record.count++;
    next();
  };

  // ---------------- API ROUTES ----------------

  // Healthcheck
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", memoriesCount: memoriesStore.length });
  });

  // Share Receiver Endpoint (Android PWA Share Target POST /api/share-receiver/:shareToken)
  app.post(
    "/api/share-receiver/:shareToken",
    rateLimiter,
    upload.single("image"),
    (req: express.Request, res: express.Response) => {
      const shareToken = req.params.shareToken;
      const tokenRecord = validateShareToken(shareToken);

      if (!tokenRecord) {
        return res.status(404).json({ error: "Invalid share token" });
      }

      const { title, text, url } = req.body;
      const file = req.file;

      const memoryTitle = title || (text ? text.slice(0, 40) + "..." : "Shared Snippet");
      const memoryBody = text || null;
      const extractedLink = url || extractUrl(text) || null;

      let imageUrl: string | null = null;
      let imageType: string | null = null;

      if (file) {
        imageUrl = `/uploads/${file.filename}`;
        imageType = file.mimetype;
      }

      const newMemory: StoredMemory = {
        id: crypto.randomUUID(),
        userId: tokenRecord.userId,
        title: String(memoryTitle).trim(),
        body: memoryBody ? String(memoryBody).trim() : null,
        link: extractedLink ? String(extractedLink).trim() : null,
        imageUrl,
        imageType,
        createdAt: new Date().toISOString(),
        isPinned: false,
        archivedAt: null,
      };

      memoriesStore.unshift(newMemory);
      saveMemories(memoriesStore);

      // Respond according to accept headers
      if (req.accepts("json")) {
        return res.status(200).json({ success: true, memory: newMemory });
      }

      // Default PWA Share Target response: 204 No Content for seamless mobile dismiss
      res.status(204).end();
    }
  );

  // Get Memories (Polling endpoint for dashboard)
  app.get("/api/memories", (req, res) => {
    let authHeader = req.headers.authorization;
    let token = authHeader ? authHeader.replace("Bearer ", "").trim() : (req.query.token as string);

    if (!token && tokensStore.length > 0) {
      // Fallback to primary token if single user local dev
      token = tokensStore[0].shareToken;
    }

    const tokenRecord = validateShareToken(token);
    if (!tokenRecord) {
      return res.status(401).json({ error: "Unauthorized: Invalid or missing token" });
    }

    // Filter memories created within last 24 hours OR pinned
    const now = Date.now();
    const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
    const sinceParam = req.query.since ? new Date(req.query.since as string).getTime() : 0;

    const userMemories = memoriesStore.filter((m) => {
      if (m.userId !== tokenRecord.userId) return false;
      const createdAtMs = new Date(m.createdAt).getTime();
      const ageMs = now - createdAtMs;
      const isUnexpired = ageMs <= TWENTY_FOUR_HOURS || m.isPinned;
      const isNewerThanSince = createdAtMs > sinceParam;
      return isUnexpired && isNewerThanSince;
    });

    res.json({
      snippets: userMemories,
      serverTime: new Date().toISOString(),
    });
  });

  // Direct Web POST memory (From Dashboard UI)
  app.post("/api/memories", upload.single("image"), (req, res) => {
    let authHeader = req.headers.authorization;
    let token = authHeader ? authHeader.replace("Bearer ", "").trim() : (req.body.token as string);

    if (!token && tokensStore.length > 0) {
      token = tokensStore[0].shareToken;
    }

    const tokenRecord = validateShareToken(token);
    if (!tokenRecord) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { title, text, url, base64Image } = req.body;
    const file = req.file;

    let imageUrl: string | null = null;
    let imageType: string | null = null;

    if (file) {
      imageUrl = `/uploads/${file.filename}`;
      imageType = file.mimetype;
    } else if (base64Image && base64Image.startsWith("data:image/")) {
      try {
        const matches = base64Image.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
        if (matches) {
          imageType = matches[1];
          const buffer = Buffer.from(matches[2], "base64");
          const ext = getExtensionFromMime(imageType);
          const filename = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}${ext}`;
          fs.writeFileSync(path.join(UPLOADS_DIR, filename), buffer);
          imageUrl = `/uploads/${filename}`;
        }
      } catch (err) {
        console.error("Error processing base64 image:", err);
      }
    }

    const memoryTitle = title || (text ? text.slice(0, 40) + "..." : "Dashboard Snippet");
    const memoryBody = text || null;
    const extractedLink = url || extractUrl(text) || null;

    const newMemory: StoredMemory = {
      id: crypto.randomUUID(),
      userId: tokenRecord.userId,
      title: String(memoryTitle).trim(),
      body: memoryBody ? String(memoryBody).trim() : null,
      link: extractedLink ? String(extractedLink).trim() : null,
      imageUrl,
      imageType,
      createdAt: new Date().toISOString(),
      isPinned: false,
      archivedAt: null,
    };

    memoriesStore.unshift(newMemory);
    saveMemories(memoriesStore);

    res.status(201).json(newMemory);
  });

  // Toggle Pin Status (v1.1 roadmap preview)
  app.patch("/api/memories/:id/pin", (req, res) => {
    const { id } = req.params;
    const memory = memoriesStore.find((m) => m.id === id);

    if (!memory) {
      return res.status(404).json({ error: "Snippet not found" });
    }

    memory.isPinned = !memory.isPinned;
    saveMemories(memoriesStore);
    res.json(memory);
  });

  // Delete Memory
  app.delete("/api/memories/:id", (req, res) => {
    const { id } = req.params;
    const index = memoriesStore.findIndex((m) => m.id === id);

    if (index === -1) {
      return res.status(404).json({ error: "Memory not found" });
    }

    const [deleted] = memoriesStore.splice(index, 1);
    saveMemories(memoriesStore);

    if (deleted.imageUrl) {
      const filename = path.basename(deleted.imageUrl);
      const filePath = path.join(UPLOADS_DIR, filename);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (e) {
          console.error("Failed to delete image file:", e);
        }
      }
    }

    res.json({ success: true, deletedId: id });
  });

  // Generate / Get User Tokens
  app.get("/api/tokens/active", (_req, res) => {
    if (tokensStore.length === 0) {
      const newToken: StoredToken = {
        userId: "user_" + crypto.randomUUID().slice(0, 8),
        shareToken: "cz-" + crypto.randomUUID().replace(/-/g, ""),
        createdAt: new Date().toISOString(),
      };
      tokensStore.push(newToken);
      saveTokens(tokensStore);
    }

    const activeToken = tokensStore[0];
    const host = process.env.APP_URL || `http://localhost:${PORT}`;

    res.json({
      userId: activeToken.userId,
      shareToken: activeToken.shareToken,
      shareUrl: `${host}/api/share-receiver/${activeToken.shareToken}`,
      manifestUrl: `${host}/api/manifest/${activeToken.shareToken}`,
    });
  });

  app.post("/api/tokens/rotate", (_req, res) => {
    const newToken: StoredToken = {
      userId: tokensStore[0]?.userId || "user_demo",
      shareToken: "cz-" + crypto.randomUUID().replace(/-/g, ""),
      createdAt: new Date().toISOString(),
    };

    tokensStore = [newToken];
    saveTokens(tokensStore);

    const host = process.env.APP_URL || `http://localhost:${PORT}`;
    res.json({
      userId: newToken.userId,
      shareToken: newToken.shareToken,
      shareUrl: `${host}/api/share-receiver/${newToken.shareToken}`,
      manifestUrl: `${host}/api/manifest/${newToken.shareToken}`,
    });
  });

  // Dynamic PWA Manifest Generator with embedded user share_token
  app.get("/api/manifest/:shareToken", (req, res) => {
    const { shareToken } = req.params;
    const manifest = {
      name: "CopyZap",
      short_name: "CopyZap",
      description: "Local-first ephemeral bridge between your phone and PC",
      start_url: "/?mode=pwa",
      display: "standalone",
      background_color: "#0f172a",
      theme_color: "#0f172a",
      icons: [
        {
          src: "/icon-192.png",
          sizes: "192x192",
          type: "image/png",
          purpose: "any maskable",
        },
        {
          src: "/icon-512.png",
          sizes: "512x512",
          type: "image/png",
          purpose: "any maskable",
        },
      ],
      share_target: {
        action: `/api/share-receiver/${shareToken}`,
        method: "POST",
        enctype: "multipart/form-data",
        params: {
          title: "title",
          text: "text",
          url: "url",
          files: [
            {
              name: "image",
              accept: ["image/*"],
            },
          ],
        },
      },
    };

    res.setHeader("Content-Type", "application/json");
    res.json(manifest);
  });

  // Explicit Cleanup endpoint for Cron or manual triggers
  app.post("/api/cleanup", (req, res) => {
    const deletedCount = performCleanup();
    res.json({ deleted: deletedCount });
  });

  // URL Link Metadata Scraper preview helper
  app.get("/api/link-preview", async (req, res) => {
    const targetUrl = req.query.url as string;
    if (!targetUrl) return res.status(400).json({ error: "Missing url parameter" });

    try {
      const parsed = new URL(targetUrl);
      const domain = parsed.hostname;
      const favicon = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;

      res.json({
        title: domain,
        domain,
        favicon,
        url: targetUrl,
      });
    } catch {
      res.status(400).json({ error: "Invalid URL" });
    }
  });

  // Vite development vs production server mounting
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CopyZap Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
