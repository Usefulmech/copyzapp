import React, { useState, useEffect, useCallback } from "react";
import { AnimatePresence } from "motion/react";
import { Memory, UserTokenInfo } from "./types";
import { Header } from "./components/Header";
import { MemoryCard } from "./components/MemoryCard";
import { PairingModal } from "./components/PairingModal";
import { ShareSheetTester } from "./components/ShareSheetTester";
import { QuickAddModal } from "./components/QuickAddModal";
import { LightboxModal } from "./components/LightboxModal";
import { Toast } from "./components/Toast";
import {
  Search,
  Filter,
  Smartphone,
  Zap,
  Trash2,
  RefreshCw,
  Plus,
  QrCode,
  ShieldCheck,
  Clock,
  Sparkles,
  Link as LinkIcon,
  FileText,
  Image as ImageIcon,
  Pin,
  Info,
  ChevronRight
} from "lucide-react";

export default function App() {
  const [tokenInfo, setTokenInfo] = useState<UserTokenInfo | null>(null);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isPolling, setIsPolling] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeFilter, setActiveFilter] = useState<"all" | "links" | "text" | "images" | "pinned">("all");

  // Modals state
  const [isPairingOpen, setIsPairingOpen] = useState<boolean>(false);
  const [isTesterOpen, setIsTesterOpen] = useState<boolean>(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState<boolean>(false);
  const [activeLightboxImage, setActiveLightboxImage] = useState<{ url: string; title: string } | null>(null);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // PWA Install Prompt
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState<any>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Listen for PWA Install Prompt
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredInstallPrompt(e);
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    return () => window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
  }, []);

  const handleInstallPwa = () => {
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      deferredInstallPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === "accepted") {
          console.log("User accepted PWA installation");
        }
        setDeferredInstallPrompt(null);
      });
    }
  };

  // Fetch or initialize user active share token
  const fetchActiveToken = async () => {
    try {
      const res = await fetch("/api/tokens/active");
      if (res.ok) {
        const data: UserTokenInfo = await res.json();
        setTokenInfo(data);
        // Update manifest link in head dynamically
        const manifestEl = document.getElementById("pwa-manifest-link") as HTMLLinkElement;
        if (manifestEl && data.manifestUrl) {
          manifestEl.href = data.manifestUrl;
        }
        return data;
      }
    } catch (err) {
      console.warn("Active token fetch warning:", err);
    }
    return null;
  };

  // Fetch memories from backend
  const fetchMemories = useCallback(async (token?: string, silent = false) => {
    if (!silent) setIsPolling(true);
    const activeToken = token || tokenInfo?.shareToken;
    if (!activeToken) {
      setLoading(false);
      setIsPolling(false);
      return;
    }

    try {
      const res = await fetch(`/api/memories?token=${activeToken}`);
      if (res.ok) {
        const data = await res.json();
        setMemories(data.snippets || []);
        setLastSyncTime(new Date());
      }
    } catch (err) {
      if (!silent) {
        console.warn("Unable to connect to server:", err);
      }
    } finally {
      setLoading(false);
      setIsPolling(false);
    }
  }, [tokenInfo?.shareToken]);

  // Initial Load
  useEffect(() => {
    const init = async () => {
      const tokenData = await fetchActiveToken();
      if (tokenData) {
        fetchMemories(tokenData.shareToken);
      }
    };
    init();
  }, []);

  // 4-Second Short Polling Loop (Locked Core Spec 6.1)
  useEffect(() => {
    if (!tokenInfo?.shareToken) return;
    const interval = setInterval(() => {
      fetchMemories(tokenInfo.shareToken, true);
    }, 4000);
    return () => clearInterval(interval);
  }, [tokenInfo?.shareToken, fetchMemories]);

  // Paste handler for PC Dashboard (Ctrl+V)
  useEffect(() => {
    const handleGlobalPaste = async (e: ClipboardEvent) => {
      // Don't intercept if typing in an input
      const targetTag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      if (targetTag === "input" || targetTag === "textarea") return;

      if (!tokenInfo?.shareToken) return;

      const clipboardData = e.clipboardData;
      if (!clipboardData) return;

      const pastedText = clipboardData.getData("text");
      const files = Array.from(clipboardData.files);

      if (pastedText || files.length > 0) {
        e.preventDefault();
        const formData = new FormData();
        formData.append("token", tokenInfo.shareToken);

        if (files.length > 0) {
          formData.append("image", files[0]);
          formData.append("title", "Pasted Image");
        } else if (pastedText) {
          formData.append("text", pastedText);
          formData.append("title", pastedText.length > 30 ? pastedText.slice(0, 30) + "..." : "Pasted Snippet");
        }

        try {
          const res = await fetch("/api/memories", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${tokenInfo.shareToken}`,
            },
            body: formData,
          });

          if (res.ok) {
            showToast("Pasted directly from clipboard!");
            fetchMemories(tokenInfo.shareToken);
          }
        } catch (err) {
          console.error("Paste upload error:", err);
        }
      }
    };

    window.addEventListener("paste", handleGlobalPaste);
    return () => window.removeEventListener("paste", handleGlobalPaste);
  }, [tokenInfo?.shareToken, fetchMemories]);

  // Handlers for Memory Actions
  const handleDeleteMemory = async (id: string) => {
    try {
      const res = await fetch(`/api/memories/${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        setMemories((prev) => prev.filter((m) => m.id !== id));
        showToast("Deleted memory snippet");
      }
    } catch (err) {
      console.error("Delete error:", err);
    }
  };

  const handleTogglePin = async (id: string) => {
    try {
      const res = await fetch(`/api/memories/${id}/pin`, {
        method: "PATCH",
      });
      if (res.ok) {
        const updated = await res.json();
        setMemories((prev) =>
          prev.map((m) => (m.id === id ? { ...m, isPinned: updated.isPinned } : m))
        );
        showToast(updated.isPinned ? "Snippet Pinned (Immune to 24h cleanup)" : "Snippet Unpinned");
      }
    } catch (err) {
      console.error("Pin error:", err);
    }
  };

  const handleRotateToken = async () => {
    if (confirm("Are you sure you want to rotate your share token? Your old phone share link will stop working.")) {
      try {
        const res = await fetch("/api/tokens/rotate", { method: "POST" });
        if (res.ok) {
          const newToken = await res.json();
          setTokenInfo(newToken);
          showToast("Share token rotated!");
          fetchMemories(newToken.shareToken);
        }
      } catch (err) {
        console.error("Rotate token error:", err);
      }
    }
  };

  // Filter & Search Logic
  const filteredMemories = memories.filter((memory) => {
    // Type Filter
    if (activeFilter === "links" && !memory.link) return false;
    if (activeFilter === "text" && (memory.link || memory.imageUrl)) return false;
    if (activeFilter === "images" && !memory.imageUrl) return false;
    if (activeFilter === "pinned" && !memory.isPinned) return false;

    // Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = memory.title?.toLowerCase().includes(q);
      const matchBody = memory.body?.toLowerCase().includes(q);
      const matchLink = memory.link?.toLowerCase().includes(q);
      return matchTitle || matchBody || matchLink;
    }

    return true;
  });

  return (
    <div className="min-h-screen bg-[#0B0B0C] text-[#E0E0E1] flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Header */}
      <Header
        tokenInfo={tokenInfo}
        isPolling={isPolling}
        lastSyncTime={lastSyncTime}
        onRefresh={() => tokenInfo?.shareToken && fetchMemories(tokenInfo.shareToken)}
        onOpenPairing={() => setIsPairingOpen(true)}
        onOpenTester={() => setIsTesterOpen(true)}
        onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        canInstallPwa={Boolean(deferredInstallPrompt)}
        onInstallPwa={handleInstallPwa}
      />

      {/* Hero Banner / Instructions Prompt Bar */}
      <div className="bg-[#161618] border-b border-[#1A1A1C] py-3 px-3 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 text-gray-300">
            <span className="p-1.5 rounded-md bg-[#212124] text-emerald-400 border border-[#2A2A2C] shrink-0">
              <Zap className="w-4 h-4 fill-emerald-400/20" />
            </span>
            <div className="font-mono text-[11px] sm:text-xs">
              <span className="font-semibold text-[#E0E0E1]">Phone to PC Stream:</span>{" "}
              Share from Android Chrome, Twitter, Photos or YouTube → Appears here instantly.{" "}
              <span className="text-emerald-400 font-medium hidden sm:inline">
                Auto-vanishes in 24 hours. No cleanup needed.
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto justify-end">
            <button
              onClick={() => setIsPairingOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#212124] hover:bg-[#2A2A2C] text-gray-200 text-[11px] font-mono font-medium border border-[#2A2A2C] transition-colors"
            >
              <QrCode className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Pair Phone QR</span>
            </button>
            <button
              onClick={() => setIsTesterOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-[11px] font-mono font-medium border border-emerald-500/30 transition-colors"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Simulate Share Sheet</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Dashboard */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-5 sm:py-8 space-y-6">
        {/* Search & Filter Toolbar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#161618] p-3 rounded-xl border border-[#2A2A2C]">
          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 font-mono">
            <button
              onClick={() => setActiveFilter("all")}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all whitespace-nowrap ${
                activeFilter === "all"
                  ? "bg-emerald-500 text-black font-bold shadow-md shadow-emerald-500/10"
                  : "bg-[#212124] text-gray-400 hover:text-gray-200 border border-[#2A2A2C]"
              }`}
            >
              All ({memories.length})
            </button>
            <button
              onClick={() => setActiveFilter("links")}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all whitespace-nowrap ${
                activeFilter === "links"
                  ? "bg-emerald-500 text-black font-bold shadow-md shadow-emerald-500/10"
                  : "bg-[#212124] text-gray-400 hover:text-gray-200 border border-[#2A2A2C]"
              }`}
            >
              <LinkIcon className="w-3.5 h-3.5" />
              <span>Links</span>
            </button>
            <button
              onClick={() => setActiveFilter("text")}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all whitespace-nowrap ${
                activeFilter === "text"
                  ? "bg-emerald-500 text-black font-bold shadow-md shadow-emerald-500/10"
                  : "bg-[#212124] text-gray-400 hover:text-gray-200 border border-[#2A2A2C]"
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Text</span>
            </button>
            <button
              onClick={() => setActiveFilter("images")}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all whitespace-nowrap ${
                activeFilter === "images"
                  ? "bg-emerald-500 text-black font-bold shadow-md shadow-emerald-500/10"
                  : "bg-[#212124] text-gray-400 hover:text-gray-200 border border-[#2A2A2C]"
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Images</span>
            </button>
            <button
              onClick={() => setActiveFilter("pinned")}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all whitespace-nowrap ${
                activeFilter === "pinned"
                  ? "bg-amber-500 text-black font-bold shadow-md shadow-amber-500/10"
                  : "bg-[#212124] text-gray-400 hover:text-gray-200 border border-[#2A2A2C]"
              }`}
            >
              <Pin className="w-3.5 h-3.5" />
              <span>Pinned</span>
            </button>
          </div>

          {/* Search Box */}
          <div className="relative min-w-[220px] sm:w-64 font-mono">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search snippets..."
              className="w-full pl-9 pr-3.5 py-1.5 bg-[#0E0E10] border border-[#2A2A2C] rounded-lg text-xs text-[#E0E0E1] focus:outline-none focus:border-emerald-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-gray-500 hover:text-gray-300"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Loading Spinner */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-16 space-y-3">
            <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
            <span className="text-xs text-gray-400 font-mono">Syncing stream with CopyZap bridge...</span>
          </div>
        )}

        {/* Empty State */}
        {!loading && filteredMemories.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 px-4 rounded-xl bg-[#161618] border border-[#2A2A2C] text-center max-w-lg mx-auto space-y-4">
            <div className="w-16 h-16 rounded-lg bg-[#212124] border border-[#2A2A2C] flex items-center justify-center text-emerald-400">
              <Zap className="w-8 h-8 stroke-[2]" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-[#E0E0E1]">
                {searchQuery || activeFilter !== "all"
                  ? "No matching snippets found"
                  : "Nothing here yet"}
              </h3>
              <p className="text-xs text-gray-400 font-mono">
                {searchQuery || activeFilter !== "all"
                  ? "Try clearing your search query or switching filters."
                  : "Share text, links, or photos from your Android phone or test with the Android Share Sheet Simulator!"}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2 font-mono">
              <button
                onClick={() => setIsTesterOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 border border-emerald-500/30 transition-colors"
              >
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Test Android Share Sheet</span>
              </button>
              <button
                onClick={() => setIsQuickAddOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold bg-emerald-500 text-black hover:bg-emerald-400 transition-colors shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Quick Add Snippet</span>
              </button>
            </div>
          </div>
        )}

        {/* Memory Snippets Grid Stream */}
        {!loading && filteredMemories.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            <AnimatePresence mode="popLayout">
              {filteredMemories.map((memory) => (
                <MemoryCard
                  key={memory.id}
                  memory={memory}
                  onDelete={handleDeleteMemory}
                  onTogglePin={handleTogglePin}
                  onOpenImage={(url, title) => setActiveLightboxImage({ url, title })}
                  onToast={showToast}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </main>

      {/* Footer / Core Principles */}
      <footer className="bg-[#161618] border-t border-[#1A1A1C] py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-400 font-mono">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-[#E0E0E1]">CopyZap Bridge</span>
            <span>— Phone to PC local-first ephemeral holding tank</span>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-[11px]">
            <span className="flex items-center gap-1.5 text-gray-300">
              <Clock className="w-3 h-3 text-emerald-400" />
              <span>Ephemeral 24h Auto-Expiry</span>
            </span>
            <span className="flex items-center gap-1.5 text-gray-300">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>Capability Token Isolation</span>
            </span>
            <span className="flex items-center gap-1.5 text-gray-300">
              <Smartphone className="w-3 h-3 text-emerald-400" />
              <span>Android Share Sheet Target</span>
            </span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <PairingModal
        isOpen={isPairingOpen}
        onClose={() => setIsPairingOpen(false)}
        tokenInfo={tokenInfo}
        onRotateToken={handleRotateToken}
      />

      <ShareSheetTester
        isOpen={isTesterOpen}
        onClose={() => setIsTesterOpen(false)}
        tokenInfo={tokenInfo}
        onShareSuccess={() => {
          if (tokenInfo?.shareToken) {
            fetchMemories(tokenInfo.shareToken);
          }
          showToast("New share received in < 2s!");
        }}
      />

      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        tokenInfo={tokenInfo}
        onAdded={() => {
          if (tokenInfo?.shareToken) {
            fetchMemories(tokenInfo.shareToken);
          }
          showToast("Added memory snippet!");
        }}
      />

      {activeLightboxImage && (
        <LightboxModal
          imageUrl={activeLightboxImage.url}
          title={activeLightboxImage.title}
          onClose={() => setActiveLightboxImage(null)}
        />
      )}

      {/* Toast Notification */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
    </div>
  );
}
