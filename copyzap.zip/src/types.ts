export interface Memory {
  id: string;
  userId: string;
  title: string;
  body?: string | null;
  link?: string | null;
  imageUrl?: string | null;
  imageType?: string | null;
  createdAt: string; // ISO 8601 string
  isPinned?: boolean;
  archivedAt?: string | null;
}

export interface ShareReceiverResponse {
  success: boolean;
  message?: string;
  memory?: Memory;
}

export interface MemoriesResponse {
  snippets: Memory[];
  serverTime: string;
}

export interface UserTokenInfo {
  shareToken: string;
  userId: string;
  shareUrl: string;
  manifestUrl: string;
}
