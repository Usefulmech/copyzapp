import React from "react";
import { UserTokenInfo } from "../types";
import {
  Zap,
  Smartphone,
  QrCode,
  Plus,
  RefreshCw,
  Laptop,
  CheckCircle2,
  Clock,
  Download
} from "lucide-react";

interface HeaderProps {
  tokenInfo: UserTokenInfo | null;
  isPolling: boolean;
  lastSyncTime: Date | null;
  onRefresh: () => void;
  onOpenPairing: () => void;
  onOpenTester: () => void;
  onOpenQuickAdd: () => void;
  onInstallPwa?: () => void;
  canInstallPwa?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  tokenInfo,
  isPolling,
  lastSyncTime,
  onRefresh,
  onOpenPairing,
  onOpenTester,
  onOpenQuickAdd,
  onInstallPwa,
  canInstallPwa,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0B0B0C]/95 backdrop-blur-xl border-b border-[#1A1A1C]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand & Logo */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          <div className="w-9 h-9 bg-emerald-500 rounded-md flex items-center justify-center text-black font-extrabold tracking-tight shrink-0 shadow-sm">
            CZ
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold text-[#E0E0E1] tracking-tight">CopyZap</h1>
            </div>
            <p className="text-[11px] text-gray-500 font-mono hidden sm:block">
              Ephemeral Phone → PC Bridge • 24h Auto-Expiry
            </p>
          </div>
        </div>

        {/* Live Sync Status Indicator */}
        <div className="hidden lg:flex items-center gap-2.5 px-3 py-1.5 rounded-md bg-[#161618] border border-[#2A2A2C] text-xs font-mono text-gray-300">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="uppercase text-[11px] tracking-wider text-gray-400">Connected</span>
          {lastSyncTime && (
            <span className="text-gray-500 text-[10px]">
              • {lastSyncTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
            </span>
          )}
          <button
            onClick={onRefresh}
            title="Force refresh stream"
            className="p-1 hover:text-emerald-400 text-gray-400 rounded transition-colors ml-1"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isPolling ? "animate-spin" : ""}`} />
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Share Sheet Simulator Trigger */}
          <button
            onClick={onOpenTester}
            title="Test Share Sheet"
            className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-md text-xs font-semibold bg-[#161618] hover:bg-[#2A2A2C] text-[#E0E0E1] border border-[#2A2A2C] transition-all"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="hidden md:inline">Test Share Sheet</span>
          </button>

          {/* QR Code / Phone Pair Button */}
          <button
            onClick={onOpenPairing}
            title="Pair Phone"
            className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-md text-xs font-semibold bg-[#161618] hover:bg-[#2A2A2C] text-[#E0E0E1] border border-[#2A2A2C] transition-all"
          >
            <QrCode className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="hidden md:inline">Pair Phone</span>
          </button>

          {/* Windows PWA Install Button (If installable) */}
          {canInstallPwa && onInstallPwa && (
            <button
              onClick={onInstallPwa}
              title="Install PWA"
              className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-md text-xs font-semibold bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20 border border-indigo-500/30 transition-all"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <span className="hidden md:inline">Install PWA</span>
            </button>
          )}

          {/* Direct Quick Add Button */}
          <button
            onClick={onOpenQuickAdd}
            className="inline-flex items-center gap-1.5 px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-md text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-black shadow-sm transition-all shrink-0"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5] shrink-0" />
            <span>Quick Add</span>
          </button>
        </div>
      </div>
    </header>
  );
};
