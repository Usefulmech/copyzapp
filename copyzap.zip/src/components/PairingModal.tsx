import React, { useState, useEffect } from "react";
import QRCode from "qrcode";
import { UserTokenInfo } from "../types";
import {
  X,
  Smartphone,
  Copy,
  Check,
  RefreshCw,
  QrCode,
  Laptop,
  ShieldCheck,
  Share2,
  ExternalLink,
  ChevronRight,
  Info
} from "lucide-react";

interface PairingModalProps {
  isOpen: boolean;
  onClose: () => void;
  tokenInfo: UserTokenInfo | null;
  onRotateToken: () => void;
}

export const PairingModal: React.FC<PairingModalProps> = ({
  isOpen,
  onClose,
  tokenInfo,
  onRotateToken,
}) => {
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>("");
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [copiedToken, setCopiedToken] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<"qr" | "android" | "windows" | "ios">("qr");

  useEffect(() => {
    if (tokenInfo?.shareUrl) {
      QRCode.toDataURL(tokenInfo.shareUrl, {
        width: 300,
        margin: 2,
        color: {
          dark: "#0f172a",
          light: "#ffffff",
        },
      })
        .then((url) => setQrCodeDataUrl(url))
        .catch((err) => console.error("QR Code Error:", err));
    }
  }, [tokenInfo]);

  if (!isOpen || !tokenInfo) return null;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(tokenInfo.shareUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleCopyToken = () => {
    navigator.clipboard.writeText(tokenInfo.shareToken);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-[#161618] border border-[#2A2A2C] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#2A2A2C] bg-[#161618]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#212124] border border-[#2A2A2C] flex items-center justify-center text-emerald-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#E0E0E1] flex items-center gap-2">
                Phone Pairing & Setup
              </h2>
              <p className="text-xs text-gray-400 font-mono">
                Connect your Android phone or Windows PC to your personal bridge
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-200 hover:bg-[#212124] rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#2A2A2C] bg-[#0E0E10] px-5 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab("qr")}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === "qr"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-gray-400 hover:text-gray-200"
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Scan QR Code</span>
          </button>
          <button
            onClick={() => setActiveTab("android")}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === "android"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-gray-400 hover:text-gray-200"
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Android Share Sheet</span>
          </button>
          <button
            onClick={() => setActiveTab("windows")}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === "windows"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-gray-400 hover:text-gray-200"
            }`}
          >
            <Laptop className="w-4 h-4" />
            <span>Windows PWA</span>
          </button>
          <button
            onClick={() => setActiveTab("ios")}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === "ios"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-gray-400 hover:text-gray-200"
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span>Apple Shortcuts</span>
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 custom-scrollbar">
          {activeTab === "qr" && (
            <div className="flex flex-col md:flex-row gap-6 items-center">
              <div className="flex flex-col items-center justify-center p-4 bg-white rounded-xl shadow-inner border border-gray-200 shrink-0">
                {qrCodeDataUrl ? (
                  <img
                    src={qrCodeDataUrl}
                    alt="CopyZap Phone Pairing QR Code"
                    className="w-56 h-56 object-contain"
                  />
                ) : (
                  <div className="w-56 h-56 flex items-center justify-center text-gray-500 font-mono text-xs">
                    Generating QR...
                  </div>
                )}
                <span className="text-[10px] font-mono font-medium text-gray-600 mt-2">
                  Scan with Android / Phone Camera
                </span>
              </div>

              <div className="flex-1 space-y-4">
                <div className="p-4 rounded-lg bg-[#0E0E10] border border-[#2A2A2C] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-gray-400">Personal Share Target URL</span>
                    <button
                      onClick={handleCopyUrl}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono font-medium bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/30 rounded transition-colors"
                    >
                      {copiedUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedUrl ? "Copied!" : "Copy URL"}</span>
                    </button>
                  </div>
                  <div className="p-2.5 bg-[#161618] rounded border border-[#2A2A2C] font-mono text-xs text-emerald-300 break-all select-all">
                    {tokenInfo.shareUrl}
                  </div>
                  <p className="text-[11px] text-gray-400 flex items-center gap-1.5 font-mono">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Capability token protected. Unguessable 128-bit isolated endpoint.</span>
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-[#0E0E10] border border-[#2A2A2C] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-gray-400">Share Token Key</span>
                    <button
                      onClick={handleCopyToken}
                      className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-mono bg-[#212124] text-gray-300 hover:bg-[#2A2A2C] rounded transition-colors"
                    >
                      {copiedToken ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedToken ? "Copied" : "Copy"}</span>
                    </button>
                  </div>
                  <div className="font-mono text-xs text-gray-300 bg-[#161618] p-2 rounded border border-[#2A2A2C]">
                    {tokenInfo.shareToken}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={onRotateToken}
                    className="inline-flex items-center gap-2 text-xs font-mono text-rose-400 hover:text-rose-300 transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Rotate Share Token (Invalidates old link)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "android" && (
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 text-xs flex items-start gap-3">
                <Info className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold block text-emerald-300 mb-1">
                    Native Android Share Sheet Setup
                  </strong>
                  CopyZap registers as an official OS Share Target via Web App Manifest. Once added to your phone home screen, CopyZap will show up whenever you hit "Share" in Android Chrome, Twitter, Photos, YouTube, or Files!
                </div>
              </div>

              <ol className="space-y-3 text-sm text-gray-300">
                <li className="flex items-start gap-3 p-3 rounded-lg bg-[#0E0E10] border border-[#2A2A2C]">
                  <span className="w-6 h-6 rounded bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                    1
                  </span>
                  <div>
                    <span className="font-medium text-[#E0E0E1]">Scan or open phone browser</span>
                    <p className="text-xs text-gray-400 font-mono mt-0.5">
                      Open Chrome on Android and navigate to: <code className="text-emerald-300 font-mono">{window.location.origin}</code>
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-3 p-3 rounded-lg bg-[#0E0E10] border border-[#2A2A2C]">
                  <span className="w-6 h-6 rounded bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                    2
                  </span>
                  <div>
                    <span className="font-medium text-[#E0E0E1]">Tap Chrome Menu (⋮) → "Add to Home Screen"</span>
                    <p className="text-xs text-gray-400 font-mono mt-0.5">
                      This installs CopyZap as a Web App with the Web Share Target manifest registered.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-3 p-3 rounded-lg bg-[#0E0E10] border border-[#2A2A2C]">
                  <span className="w-6 h-6 rounded bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                    3
                  </span>
                  <div>
                    <span className="font-medium text-[#E0E0E1]">Share from any app to CopyZap</span>
                    <p className="text-xs text-gray-400 font-mono mt-0.5">
                      Tap share on any photo, URL, or text in Android → Select <strong className="text-gray-200">CopyZap</strong>. The share sheet closes in &lt; 2 seconds!
                    </p>
                  </div>
                </li>
              </ol>
            </div>
          )}

          {activeTab === "windows" && (
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-[#0E0E10] border border-[#2A2A2C] space-y-3">
                <h3 className="text-sm font-semibold text-[#E0E0E1] flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-emerald-400" />
                  Install Windows PWA Dashboard
                </h3>
                <p className="text-xs text-gray-400 font-mono">
                  Enjoy an app-like chromeless window on Windows 11 / 10 with auto-start, native clipboard access, and live 4-second polling.
                </p>
                <div className="p-3 bg-[#161618] rounded border border-[#2A2A2C] text-xs text-gray-300 font-mono space-y-2">
                  <p>1. In Edge or Chrome on desktop, click the <strong className="text-emerald-300">App Install icon</strong> in the address bar (or Menu → Apps → Install CopyZap).</p>
                  <p>2. Pin CopyZap to your Windows Taskbar or Start Menu.</p>
                  <p>3. Keep it running in the background for real-time snippet stream delivery!</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === "ios" && (
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-200 text-xs flex items-start gap-3">
                <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold block text-indigo-300 mb-1">
                    iOS Shortcuts Bridge
                  </strong>
                  Apple Safari restricts Web Share Target in PWAs. On iPhone/iPad, you can use Apple Shortcuts to POST directly to your CopyZap share target URL!
                </div>
              </div>

              <div className="p-4 rounded-lg bg-[#0E0E10] border border-[#2A2A2C] space-y-2 text-xs text-gray-300 font-mono">
                <p className="font-semibold text-gray-200">Creating an iOS Share Shortcut:</p>
                <ol className="list-decimal list-inside space-y-1.5 text-gray-400">
                  <li>Open Apple <strong className="text-gray-200">Shortcuts app</strong> → Create New Shortcut.</li>
                  <li>Set input to <strong className="text-gray-200">Receive Shares (Text, URLs, Images)</strong> in Share Sheet.</li>
                  <li>Add action: <strong className="text-gray-200">Get Contents of URL</strong> with POST method to your personal share URL.</li>
                  <li>Add form fields: <code className="text-indigo-300 font-mono">title</code>, <code className="text-indigo-300 font-mono">text</code>, <code className="text-indigo-300 font-mono">url</code>.</li>
                  <li>Name shortcut <strong className="text-gray-200">CopyZap</strong> and save to Share Sheet!</li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#2A2A2C] bg-[#161618] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-mono font-semibold bg-[#212124] text-gray-200 hover:bg-[#2A2A2C] rounded-lg transition-colors border border-[#2A2A2C]"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
